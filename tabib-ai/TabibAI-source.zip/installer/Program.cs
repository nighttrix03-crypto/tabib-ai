using System.Diagnostics;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;

namespace TabibAIInstaller;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new SetupForm());
    }
}

internal sealed class SetupForm : Form
{
    private const string Model = "medgemma1.5:latest";
    private const string OllamaApi = "http://localhost:11434";
    private const string OllamaInstallerUrl = "https://ollama.com/download/OllamaSetup.exe";
    private static readonly Color Ink = Color.FromArgb(27, 45, 56);
    private static readonly Color Teal = Color.FromArgb(19, 124, 127);
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromHours(2) };
    private readonly CheckBox acceptTerms = new();
    private readonly Button installButton = new();
    private readonly Label status = new();
    private readonly ProgressBar progress = new();
    private readonly string installFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "TabibAI");
    private bool installing;

    public SetupForm()
    {
        Text = "تثبيت طبيب AI";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = true;
        RightToLeft = RightToLeft.Yes;
        RightToLeftLayout = true;
        ClientSize = new Size(680, 475);
        BackColor = Color.White;
        Font = new Font("Segoe UI", 10F);

        var title = new Label { Text = "تثبيت طبيب AI على هذا الكمبيوتر", Dock = DockStyle.Top, Height = 64, Padding = new Padding(24, 14, 24, 0), ForeColor = Ink, Font = new Font("Segoe UI", 17F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleRight };
        Controls.Add(title);
        var intro = new Label
        {
            Text = "سيثبّت المعالج التطبيق، ويضيف اختصاراً على سطح المكتب وقائمة ابدأ، ثم يثبت Ollama وينزّل نموذج MedGemma الطبي ليعمل محلياً. لا تحتاج إلى كتابة مفتاح API. تحتاج هذه الخطوات اتصالاً بالإنترنت ومساحة فارغة للنموذج (نحو 3.3 GB) ووقتاً حسب سرعة الاتصال. بعد الإعداد، يعمل النموذج على هذا الكمبيوتر.",
            Dock = DockStyle.Top, Height = 135, Padding = new Padding(25, 12, 25, 10), ForeColor = Color.FromArgb(75, 95, 103), TextAlign = ContentAlignment.MiddleRight
        };
        Controls.Add(intro); Controls.SetChildIndex(intro, 0);
        var legalLink = new LinkLabel { Text = "اقرأ شروط استخدام نموذج MedGemma من Google", Dock = DockStyle.Top, Height = 34, Padding = new Padding(25, 3, 25, 3), TextAlign = ContentAlignment.MiddleRight };
        legalLink.LinkClicked += (_, _) => Process.Start(new ProcessStartInfo("https://developers.google.com/health-ai-developer-foundations/terms") { UseShellExecute = true });
        Controls.Add(legalLink); Controls.SetChildIndex(legalLink, 0);
        acceptTerms.Text = "قرأت شروط HAI-DEF وأوافق عليها؛ أفهم أن النموذج ليس معتمداً للتشخيص السريري.";
        acceptTerms.Dock = DockStyle.Top; acceptTerms.Height = 44; acceptTerms.Padding = new Padding(20, 0, 20, 0); acceptTerms.TextAlign = ContentAlignment.MiddleRight; acceptTerms.RightToLeft = RightToLeft.Yes;
        Controls.Add(acceptTerms); Controls.SetChildIndex(acceptTerms, 0);

        progress.Dock = DockStyle.Top; progress.Height = 25; progress.Style = ProgressBarStyle.Marquee; progress.MarqueeAnimationSpeed = 26; progress.Visible = false;
        Controls.Add(progress); Controls.SetChildIndex(progress, 0);
        status.Text = "سيتم تنزيل Ollama من موقعه الرسمي والتحقق من توقيع ملف التثبيت قبل تشغيله.";
        status.Dock = DockStyle.Top; status.Height = 55; status.Padding = new Padding(25, 6, 25, 6); status.ForeColor = Color.FromArgb(104, 124, 132); status.TextAlign = ContentAlignment.MiddleRight;
        Controls.Add(status); Controls.SetChildIndex(status, 0);

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 72, BackColor = Color.FromArgb(246, 249, 249), Padding = new Padding(22, 15, 22, 15) };
        installButton.Text = "تثبيت التطبيق وإعداد الذكاء الاصطناعي"; installButton.Dock = DockStyle.Right; installButton.Width = 275;
        installButton.FlatStyle = FlatStyle.Flat; installButton.FlatAppearance.BorderSize = 0; installButton.BackColor = Teal; installButton.ForeColor = Color.White; installButton.Font = new Font("Segoe UI", 9.2F, FontStyle.Bold); installButton.Cursor = Cursors.Hand;
        installButton.Click += async (_, _) => await InstallAsync();
        var cancel = new Button { Text = "إغلاق", Dock = DockStyle.Left, Width = 96, DialogResult = DialogResult.Cancel, FlatStyle = FlatStyle.Flat };
        footer.Controls.Add(installButton); footer.Controls.Add(cancel); Controls.Add(footer);
        AcceptButton = installButton; CancelButton = cancel;
        FormClosing += (_, e) => { if (installing) { e.Cancel = true; MessageBox.Show(this, "انتظر انتهاء التثبيت الجاري.", "التثبيت", MessageBoxButtons.OK, MessageBoxIcon.Information); } else http.Dispose(); };
    }

    private async Task InstallAsync()
    {
        if (installing) return;
        if (!acceptTerms.Checked)
        {
            MessageBox.Show(this, "اقرأ شروط Google عبر الرابط، ثم وافق عليها لإكمال تنزيل النموذج.", "شروط النموذج", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        installing = true; installButton.Enabled = false; installButton.Text = "جارٍ الإعداد…"; progress.Visible = true;
        try
        {
            Directory.CreateDirectory(installFolder);
            var appPath = Path.Combine(installFolder, "TabibAI.exe");
            status.Text = "ينسخ التطبيق إلى مجلد المستخدم…";
            await CopyEmbeddedApplicationAsync(appPath);
            await WriteModelNoticeAsync();
            CreateShortcuts(appPath);

            if (!await OllamaIsReadyAsync())
            {
                var ollamaSetup = Path.Combine(Path.GetTempPath(), "OllamaSetup.exe");
                await DownloadFileAsync(OllamaInstallerUrl, ollamaSetup, "جارٍ تنزيل Ollama الرسمي…");
                status.Text = "يتحقق Windows من توقيع Ollama…";
                await VerifyAuthenticodeAsync(ollamaSetup);
                status.Text = "يثبت Ollama بصمت للمستخدم الحالي…";
                using var proc = Process.Start(new ProcessStartInfo(ollamaSetup, "/VERYSILENT /NORESTART /SUPPRESSMSGBOXES") { UseShellExecute = false, CreateNoWindow = true });
                if (proc is null) throw new InvalidOperationException("تعذر بدء مُثبّت Ollama.");
                await proc.WaitForExitAsync();
                if (proc.ExitCode != 0) throw new InvalidOperationException($"انتهى تثبيت Ollama بالرمز {proc.ExitCode}.");
            }

            status.Text = "ينتظر بدء خدمة Ollama المحلية…";
            if (!await WaitForOllamaAsync(TimeSpan.FromMinutes(3))) throw new InvalidOperationException("تم تثبيت Ollama، لكن الخدمة المحلية لم تبدأ. أعد تشغيل الكمبيوتر ثم شغّل TabibAI من الاختصار.");
            if (!await ModelIsInstalledAsync()) await PullModelAsync();
            status.Text = "اكتمل الإعداد. يفتح التطبيق الآن من الاختصار الذي أُنشئ على سطح المكتب.";
            progress.Style = ProgressBarStyle.Blocks; progress.Value = 100;
            MessageBox.Show(this, "اكتمل التثبيت. أُنشئ اختصار على سطح المكتب وقائمة ابدأ، واكتمل تنزيل النموذج. سيعمل التطبيق محلياً على هذا الكمبيوتر.", "اكتمل الإعداد", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Process.Start(new ProcessStartInfo(appPath) { UseShellExecute = true });
            installing = false; Close();
        }
        catch (Exception ex)
        {
            installing = false; progress.Visible = false; installButton.Enabled = true; installButton.Text = "إعادة المحاولة";
            status.Text = "تعذّر إكمال الإعداد. قد يبقى التطبيق مثبتاً؛ أعد المحاولة بعد إصلاح المشكلة.";
            MessageBox.Show(this, "تعذّر إكمال الإعداد:\n\n" + SafeError(ex.Message) + "\n\nيمكن تشغيل TabibAI.exe من مجلد التثبيت أو إعادة المحاولة.", "خطأ في التثبيت", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task CopyEmbeddedApplicationAsync(string destination)
    {
        await using var source = Assembly.GetExecutingAssembly().GetManifestResourceStream("TabibAIInstaller.TabibAI.exe")
            ?? throw new FileNotFoundException("ملف التطبيق غير موجود داخل حزمة التثبيت.");
        await using var target = new FileStream(destination, FileMode.Create, FileAccess.Write, FileShare.None, 1024 * 1024, useAsync: true);
        await source.CopyToAsync(target);
    }

    private async Task WriteModelNoticeAsync()
    {
        const string notice = "HAI-DEF is provided under and subject to the Health AI Developer Foundations Terms of Use found at https://developers.google.com/health-ai-developer-foundations/terms";
        await File.WriteAllTextAsync(Path.Combine(installFolder, "NOTICE-HAI-DEF.txt"), notice + Environment.NewLine + Environment.NewLine + "MedGemma model weights are downloaded by the user from Ollama during setup and are not included in this installer.", new UTF8Encoding(false));
        await File.WriteAllTextAsync(Path.Combine(installFolder, "HAI-DEF-Terms-URL.txt"), "https://developers.google.com/health-ai-developer-foundations/terms" + Environment.NewLine, new UTF8Encoding(false));
    }

    private void CreateShortcuts(string appPath)
    {
        var shellType = Type.GetTypeFromProgID("WScript.Shell") ?? throw new InvalidOperationException("تعذر الوصول إلى مكوّن اختصارات Windows.");
        dynamic shell = Activator.CreateInstance(shellType)!;
        string[] targets =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "TabibAI.lnk"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", "TabibAI.lnk")
        };
        foreach (var shortcutPath in targets)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(shortcutPath)!);
            dynamic shortcut = shell.CreateShortcut(shortcutPath);
            shortcut.TargetPath = appPath;
            shortcut.WorkingDirectory = installFolder;
            shortcut.Description = "مساعد طبي محلي يعمل بنموذج MedGemma";
            shortcut.IconLocation = appPath + ",0";
            shortcut.Save();
            if (Marshal.IsComObject((object)shortcut)) Marshal.FinalReleaseComObject((object)shortcut);
        }
        if (Marshal.IsComObject((object)shell)) Marshal.FinalReleaseComObject((object)shell);
    }

    private async Task DownloadFileAsync(string url, string path, string label)
    {
        status.Text = label;
        using var response = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
        response.EnsureSuccessStatusCode();
        var length = response.Content.Headers.ContentLength;
        await using var input = await response.Content.ReadAsStreamAsync();
        await using var output = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None, 128 * 1024, useAsync: true);
        var buffer = new byte[128 * 1024]; long total = 0; int read;
        while ((read = await input.ReadAsync(buffer)) > 0)
        {
            await output.WriteAsync(buffer.AsMemory(0, read)); total += read;
            if (length is > 0) status.Text = $"{label} {Math.Clamp(total * 100 / length.Value, 0, 100)}%";
        }
        await output.FlushAsync();
    }

    private static async Task VerifyAuthenticodeAsync(string file)
    {
        string escaped = file.Replace("'", "''", StringComparison.Ordinal);
        var info = new ProcessStartInfo("powershell.exe") { UseShellExecute = false, CreateNoWindow = true };
        info.ArgumentList.Add("-NoProfile"); info.ArgumentList.Add("-NonInteractive"); info.ArgumentList.Add("-Command");
        info.ArgumentList.Add($"$s=Get-AuthenticodeSignature -LiteralPath '{escaped}'; if ($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch '(^|, )O=Ollama Inc\\.(,|$)') {{ exit 1 }}");
        using var proc = Process.Start(info) ?? throw new InvalidOperationException("تعذر التحقق من توقيع مُثبّت Ollama.");
        await proc.WaitForExitAsync();
        if (proc.ExitCode != 0) throw new InvalidOperationException("ملف تثبيت Ollama لم يجتز التحقق من توقيعه الرقمي؛ أوقف التثبيت للحماية.");
    }

    private async Task<bool> OllamaIsReadyAsync()
    {
        try { using var r = await http.GetAsync(OllamaApi + "/api/tags"); return r.IsSuccessStatusCode; }
        catch { return false; }
    }

    private async Task<bool> WaitForOllamaAsync(TimeSpan timeout)
    {
        var until = DateTime.UtcNow + timeout;
        while (DateTime.UtcNow < until)
        {
            if (await OllamaIsReadyAsync()) return true;
            await Task.Delay(1500);
        }
        return false;
    }

    private async Task<bool> ModelIsInstalledAsync()
    {
        try
        {
            using var response = await http.GetAsync(OllamaApi + "/api/tags");
            if (!response.IsSuccessStatusCode) return false;
            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            return doc.RootElement.GetProperty("models").EnumerateArray().Any(m => m.GetProperty("name").GetString()?.StartsWith("medgemma1.5", StringComparison.OrdinalIgnoreCase) == true);
        }
        catch { return false; }
    }

    private async Task PullModelAsync()
    {
        status.Text = "ينزّل MedGemma (نحو 3.3 GB). اترك نافذة التثبيت مفتوحة…";
        var request = new HttpRequestMessage(HttpMethod.Post, OllamaApi + "/api/pull")
        { Content = new StringContent(JsonSerializer.Serialize(new { name = Model, stream = true }), Encoding.UTF8, "application/json") };
        using (request)
        using (var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead))
        {
            response.EnsureSuccessStatusCode();
            using var stream = await response.Content.ReadAsStreamAsync();
            using var reader = new StreamReader(stream);
            while (await reader.ReadLineAsync() is { } line)
            {
                using var evt = JsonDocument.Parse(line);
                var root = evt.RootElement;
                if (root.TryGetProperty("error", out var error)) throw new InvalidOperationException(error.GetString() ?? "رفض Ollama تنزيل النموذج.");
                string state = root.TryGetProperty("status", out var s) ? s.GetString() ?? "جارٍ التنزيل" : "جارٍ التنزيل";
                if (root.TryGetProperty("total", out var total) && total.TryGetInt64(out long all) && all > 0 && root.TryGetProperty("completed", out var completed) && completed.TryGetInt64(out long done))
                    status.Text = $"MedGemma: {state} — {Math.Clamp(done * 100 / all, 0, 100)}% (قد يحتوي النموذج على عدة ملفات)";
                else status.Text = "MedGemma: " + state;
            }
        }
        if (!await ModelIsInstalledAsync()) throw new InvalidOperationException("انتهى الاتصال دون ظهور النموذج ضمن قائمة Ollama.");
    }

    private static string SafeError(string value) => value.Length > 900 ? value[..900] + "…" : value.Replace("\r", " ").Replace("\n", " ");
}
